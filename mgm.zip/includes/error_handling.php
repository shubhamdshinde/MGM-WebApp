<?php

// error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);

?>
