<?php

$dbServerName = "localhost";
  $dbUser = "root";
  $dbPass = "";
  $dbName = "mgm";

  $con = mysqli_connect($dbServerName, $dbUser, $dbPass, $dbName);

  
?>