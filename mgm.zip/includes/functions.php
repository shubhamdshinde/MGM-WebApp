<?php

function redirect($link){

	header("Location:$link");
	return ;

}

?>
